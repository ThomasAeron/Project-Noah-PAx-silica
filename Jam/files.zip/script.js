document.addEventListener('DOMContentLoaded', () => {
  const companyDetails = {
    name: 'Cainta One Express',
    location: 'Cainta, Rizal',
    phone: '09566753142',
    email: 'rbaniqued70@gmail.com'
  };

  document.querySelectorAll('[data-location]').forEach((el) => {
    el.textContent = companyDetails.location;
  });

  document.querySelectorAll('[data-phone]').forEach((el) => {
    el.textContent = companyDetails.phone;
  });

  document.querySelectorAll('[data-email]').forEach((el) => {
    el.textContent = companyDetails.email;
    el.setAttribute('href', `mailto:${companyDetails.email}`);
  });

  const yearTarget = document.querySelector('[data-year]');
  if (yearTarget) {
    yearTarget.textContent = new Date().getFullYear();
  }

  const accountForm = document.getElementById('account-form');
  if (accountForm) {
    const accountModes = document.querySelectorAll('[data-account-mode]');
    const nameField = document.getElementById('account-name-field');
    const nameInput = document.getElementById('account-name');
    const emailInput = document.getElementById('account-email');
    const phoneField = document.getElementById('account-phone-field');
    const phoneInput = document.getElementById('account-phone');
    const codeField = document.getElementById('account-code-field');
    const codeInput = document.getElementById('account-code');
    const sendCodeButton = document.getElementById('account-send-code');
    const verifyCodeButton = document.getElementById('account-verify-code');
    const passwordInput = document.getElementById('account-password');
    const accountMessage = document.getElementById('account-message');
    const accountPanel = document.getElementById('account-panel');
    const accountFormPanel = document.getElementById('account-form-panel');
    const accountNameDisplay = document.getElementById('account-name-display');
    const accountEmailDisplay = document.getElementById('account-email-display');
    const signOutButton = document.getElementById('account-sign-out');
    const accountKey = 'coe-demo-account-v1';
    const sessionKey = 'coe-demo-session-v1';
    let codeSentPhone = '';
    let verifiedPhone = '';
    let accountMode = new URLSearchParams(window.location.search).get('mode') === 'create'
      ? 'create'
      : 'signin';

    const setAccountMessage = (message, isError = false) => {
      accountMessage.textContent = message;
      accountMessage.classList.toggle('is-error', isError);
    };

    const renderAccountMode = () => {
      const creating = accountMode === 'create';
      nameField.hidden = !creating;
      nameInput.required = creating;
      phoneField.hidden = !creating;
      phoneInput.required = creating;
      codeField.hidden = !creating || !codeSentPhone || phoneInput.value.trim() !== codeSentPhone;
      codeInput.required = creating && !verifiedPhone;
      document.getElementById('account-submit').disabled = creating && verifiedPhone !== phoneInput.value.trim();
      passwordInput.autocomplete = creating ? 'new-password' : 'current-password';
      document.getElementById('account-submit').textContent = creating ? 'Create Account' : 'Sign In';
      document.getElementById('account-heading').textContent = creating ? 'Create your account' : 'Welcome back';
      document.getElementById('account-intro').textContent = creating
        ? 'Use one account for your Cainta One Express requests.'
        : 'Sign in to your Cainta One Express account.';
      accountModes.forEach((button) => {
        const selected = button.dataset.accountMode === accountMode;
        button.setAttribute('aria-pressed', String(selected));
      });
      setAccountMessage('');
    };

    const derivePasswordHash = async (password, salt) => {
      if (!window.crypto?.subtle) {
        throw new Error('Account storage is unavailable in this browser. Open this page through a local web server.');
      }
      const key = await window.crypto.subtle.importKey(
        'raw',
        new TextEncoder().encode(password),
        'PBKDF2',
        false,
        ['deriveBits']
      );
      const bits = await window.crypto.subtle.deriveBits(
        { name: 'PBKDF2', salt, iterations: 120000, hash: 'SHA-256' },
        key,
        256
      );
      return Array.from(new Uint8Array(bits), (byte) => byte.toString(16).padStart(2, '0')).join('');
    };

    const showSignedInAccount = (account) => {
      accountNameDisplay.textContent = account.name;
      accountEmailDisplay.textContent = account.email;
      accountFormPanel.hidden = true;
      accountPanel.hidden = false;
    };

    accountModes.forEach((button) => {
      button.addEventListener('click', () => {
        accountMode = button.dataset.accountMode;
        codeSentPhone = '';
        verifiedPhone = '';
        phoneInput.value = '';
        codeInput.value = '';
        renderAccountMode();
      });
    });

    phoneInput.addEventListener('input', () => {
      const currentPhone = phoneInput.value.trim();
      if (currentPhone !== verifiedPhone) {
        verifiedPhone = '';
      }
      if (currentPhone !== codeSentPhone) {
        codeSentPhone = '';
        codeInput.value = '';
      }
      codeField.hidden = !codeSentPhone;
      document.getElementById('account-submit').disabled = accountMode === 'create' && !verifiedPhone;
    });

    sendCodeButton.addEventListener('click', async () => {
      if (!phoneInput.reportValidity()) return;
      const phone = phoneInput.value.trim();
      sendCodeButton.disabled = true;
      setAccountMessage('Sending your SMS code...');
      try {
        const response = await fetch('/api/otp/send', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ phone })
        });
        const result = await response.json();
        if (!response.ok) throw new Error(result.error || 'Could not send a verification code.');
        if (phoneInput.value.trim() !== phone) {
          throw new Error('The phone number changed. Send a new code to that number.');
        }
        codeSentPhone = phone;
        verifiedPhone = '';
        codeInput.value = '';
        codeField.hidden = false;
        codeInput.required = true;
        document.getElementById('account-submit').disabled = true;
        codeInput.focus();
        setAccountMessage(result.message || 'Verification code sent by SMS.');
      } catch (error) {
        setAccountMessage(error.message || 'Could not send a verification code.', true);
      } finally {
        sendCodeButton.disabled = false;
      }
    });

    verifyCodeButton.addEventListener('click', async () => {
      if (!codeSentPhone || phoneInput.value.trim() !== codeSentPhone) {
        setAccountMessage('Send a code to your current phone number first.', true);
        return;
      }
      const code = codeInput.value.trim();
      if (!codeInput.reportValidity()) return;
      verifyCodeButton.disabled = true;
      setAccountMessage('Verifying your phone...');
      try {
        const response = await fetch('/api/otp/check', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ phone: codeSentPhone, code })
        });
        const result = await response.json();
        if (!response.ok) throw new Error(result.error || 'That code could not be verified.');
        verifiedPhone = result.phone;
        codeInput.required = false;
        document.getElementById('account-submit').disabled = false;
        setAccountMessage('Phone number verified. You can create your account.');
      } catch (error) {
        verifiedPhone = '';
        document.getElementById('account-submit').disabled = true;
        setAccountMessage(error.message || 'That code could not be verified.', true);
      } finally {
        verifyCodeButton.disabled = false;
      }
    });

    accountForm.addEventListener('submit', async (event) => {
      event.preventDefault();
      const submitButton = document.getElementById('account-submit');
      submitButton.disabled = true;
      setAccountMessage(accountMode === 'create' ? 'Creating your account...' : 'Signing you in...');

      try {
        const email = emailInput.value.trim().toLowerCase();
        const password = passwordInput.value;
        let savedAccount = JSON.parse(localStorage.getItem(accountKey) || 'null');
        let account;

        if (accountMode === 'create') {
          if (!verifiedPhone || verifiedPhone !== phoneInput.value.trim()) {
            throw new Error('Verify your phone number before creating an account.');
          }
          if (savedAccount?.email === email) {
            throw new Error('An account with this email already exists on this browser.');
          }
          const salt = window.crypto.getRandomValues(new Uint8Array(16));
          const saltValue = Array.from(salt, (byte) => byte.toString(16).padStart(2, '0')).join('');
          const passwordHash = await derivePasswordHash(password, salt);
          account = {
            name: nameInput.value.trim(),
            email,
            phone: verifiedPhone,
            salt: saltValue,
            passwordHash
          };
          localStorage.setItem(accountKey, JSON.stringify(account));
        } else {
          if (!savedAccount || savedAccount.email !== email) {
            throw new Error('No matching account was found on this browser. Create an account first.');
          }
          const salt = Uint8Array.from(savedAccount.salt.match(/.{2}/g), (byte) => parseInt(byte, 16));
          const passwordHash = await derivePasswordHash(password, salt);
          if (passwordHash !== savedAccount.passwordHash) {
            throw new Error('That password does not match this account.');
          }
          account = savedAccount;
        }

        localStorage.setItem(sessionKey, JSON.stringify({ name: account.name, email: account.email }));
        showSignedInAccount(account);
        setAccountMessage('You are signed in on this browser.');
      } catch (error) {
        setAccountMessage(error.message || 'We could not complete that request.', true);
      } finally {
        submitButton.disabled = false;
      }
    });

    signOutButton.addEventListener('click', () => {
      localStorage.removeItem(sessionKey);
      accountPanel.hidden = true;
      accountFormPanel.hidden = false;
      accountForm.reset();
      codeSentPhone = '';
      verifiedPhone = '';
      accountMode = 'signin';
      renderAccountMode();
    });

    try {
      const currentSession = JSON.parse(localStorage.getItem(sessionKey) || 'null');
      if (currentSession?.email) {
        showSignedInAccount(currentSession);
      }
    } catch {
      localStorage.removeItem(sessionKey);
    }
    renderAccountMode();
  }

  const navLinks = document.querySelectorAll('.nav-menu a');
  const sections = [...document.querySelectorAll('main section[id]')];

  const updateActiveNav = () => {
    let currentSection = 'home';

    sections.forEach((section) => {
      const rect = section.getBoundingClientRect();
      if (rect.top <= 150 && rect.bottom >= 150) {
        currentSection = section.id;
      }
    });

    navLinks.forEach((link) => {
      const isActive = link.getAttribute('href') === `#${currentSection}`;
      link.classList.toggle('active', isActive);
    });
  };

  updateActiveNav();
  window.addEventListener('scroll', updateActiveNav, { passive: true });

  document.querySelectorAll('a[href^="#"]').forEach((link) => {
    link.addEventListener('click', (event) => {
      const targetId = link.getAttribute('href');
      if (!targetId || targetId === '#') return;

      const target = document.querySelector(targetId);
      if (!target) return;

      event.preventDefault();
      target.scrollIntoView({ behavior: 'smooth', block: 'start' });
    });
  });

  const quoteButtons = document.querySelectorAll('[data-quote]');
  quoteButtons.forEach((button) => {
    button.addEventListener('click', () => {
      const contactSection = document.getElementById('contact');
      if (contactSection) {
        contactSection.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }
    });
  });

  const statusText = document.querySelector('[data-status]');
  if (statusText) {
    statusText.textContent = 'Serving Cainta, Rizal';
  }

  const sellModal = document.getElementById('sell-modal');
  const sellTitle = document.getElementById('sell-modal-title');
  const sellSubtitle = document.getElementById('sell-modal-subtitle');
  const sellServiceField = document.getElementById('sell-service');
  const sellForm = document.getElementById('sell-form');
  const sellSuccess = document.getElementById('sell-success');
  const itemSearch = document.getElementById('item-search');
  const itemName = document.getElementById('item-name');
  const itemCategory = document.getElementById('item-category');
  const itemSuggestions = document.getElementById('item-suggestions');
  const itemCategories = document.getElementById('item-categories');
  const itemSuggestionList = document.getElementById('item-suggestion-list');
  const itemSuggestionsLabel = document.getElementById('item-suggestions-label');
  const itemSearchStatus = document.getElementById('item-search-status');
  const deliveryAddress = document.getElementById('delivery-address');
  const deliveryEstimate = document.getElementById('delivery-estimate');
  const deliveryEstimateSummary = document.getElementById('delivery-estimate-summary');
  const deliveryEstimateStatus = document.getElementById('delivery-estimate-status');
  const deliveryMapLink = document.getElementById('delivery-map-link');
  const sellSubmit = sellForm?.querySelector('[type="submit"]');
  const deliveryStart = { lat: 14.5801889, lon: 121.1146535 };
  let deliveryMap = null;
  // ---- Search items -------------------------------------------------------
  // To add or rename items, edit the lists below.
  //   item(name, category chip, form Category dropdown, other words people may type, popular?)
  const normalizeItemText = (value) => String(value)
    .toLocaleLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/[^a-z0-9]+/g, ' ')
    .trim();

  const item = (name, category, group, also = '', popular = false) => ({
    name,
    category,
    group,
    popular,
    key: normalizeItemText(name),
    icon: normalizeItemText(name).replace(/ /g, '-'),
    nameWords: normalizeItemText(name).split(' '),
    alsoWords: normalizeItemText(also).split(' ').filter(Boolean),
    categoryWords: normalizeItemText(category).split(' ')
  });

  const itemCatalog = {
    'Food Express': [
      item('Chicken', 'Fresh', 'Food', 'manok', true),
      item('Pork', 'Fresh', 'Food', 'baboy'),
      item('Beef', 'Fresh', 'Food', 'baka'),
      item('Fish', 'Fresh', 'Food', 'isda'),
      item('Eggs', 'Fresh', 'Food', 'itlog', true),
      item('Vegetables', 'Fresh', 'Food', 'gulay veggies', true),
      item('Fruits', 'Fresh', 'Food', 'prutas'),
      item('Rice', 'Pantry', 'Food', 'bigas', true),
      item('Cooking oil', 'Pantry', 'Food', 'mantika', true),
      item('Sugar', 'Pantry', 'Food', 'asukal'),
      item('Salt', 'Pantry', 'Food', 'asin'),
      item('Noodles', 'Pantry', 'Food', 'instant pancit mami'),
      item('Canned goods', 'Pantry', 'Food', 'sardines corned beef tuna'),
      item('Soy sauce', 'Pantry', 'Food', 'toyo'),
      item('Vinegar', 'Pantry', 'Food', 'suka'),
      item('Snacks', 'Snacks', 'Food', 'merienda', true),
      item('Chips', 'Snacks', 'Food', 'chichirya'),
      item('Biscuits', 'Snacks', 'Food', 'cookies crackers'),
      item('Chocolate', 'Snacks', 'Food', 'candy sweets'),
      item('Bread', 'Snacks', 'Food', 'pandesal loaf', true),
      item('Cake', 'Snacks', 'Food', 'dessert pastry'),
      item('Milk', 'Drinks', 'Food', 'gatas', true),
      item('Water', 'Drinks', 'Food', 'mineral drinking'),
      item('Juice', 'Drinks', 'Food', 'fruit drink'),
      item('Softdrinks', 'Drinks', 'Food', 'soda coke sprite'),
      item('Coffee', 'Drinks', 'Food', 'kape'),
      item('Tea', 'Drinks', 'Food', 'tsaa'),
      item('Adobo', 'Meals', 'Food', 'ulam'),
      item('Sisig', 'Meals', 'Food', 'ulam'),
      item('Pancit', 'Meals', 'Food', 'noodles ulam'),
      item('Fried chicken', 'Meals', 'Food', 'ulam'),
      item('Lumpia', 'Meals', 'Food', 'spring rolls shanghai'),
      item('Sinigang', 'Meals', 'Food', 'soup ulam')
    ],
    'Online Bazaar': [
      item('T-shirts', 'Clothing', 'Fashion', 'tshirt tee damit', true),
      item('Dresses', 'Clothing', 'Fashion', 'dress gown', true),
      item('Jeans', 'Clothing', 'Fashion', 'pants denim', true),
      item('Shorts', 'Clothing', 'Fashion', 'pants'),
      item('Polo shirts', 'Clothing', 'Fashion', 'polo'),
      item('Hoodies', 'Clothing', 'Fashion', 'sweater jacket'),
      item('Jackets', 'Clothing', 'Fashion', 'coat windbreaker'),
      item('Pajamas', 'Clothing', 'Fashion', 'sleepwear pambahay'),
      item('Shoes', 'Shoes', 'Fashion', 'sapatos', true),
      item('Sneakers', 'Shoes', 'Fashion', 'rubber shoes'),
      item('Sandals', 'Shoes', 'Fashion', 'strappy'),
      item('Slippers', 'Shoes', 'Fashion', 'tsinelas flip flops'),
      item('Boots', 'Shoes', 'Fashion', 'rain boots'),
      item('Bags', 'Bags', 'Fashion', 'bag', true),
      item('Backpacks', 'Bags', 'Fashion', 'school bag'),
      item('Handbags', 'Bags', 'Fashion', 'purse'),
      item('Wallets', 'Bags', 'Fashion', 'wallet'),
      item('Accessories', 'Accessories', 'Fashion', 'fashion', true),
      item('Caps', 'Accessories', 'Fashion', 'hat'),
      item('Watches', 'Accessories', 'Fashion', 'relo watch'),
      item('Sunglasses', 'Accessories', 'Fashion', 'shades'),
      item('Belts', 'Accessories', 'Fashion', 'belt'),
      item('Jewelry', 'Accessories', 'Fashion', 'necklace bracelet earrings ring'),
      item('Home decor', 'Home', 'Home', 'decoration', true),
      item('Bed sheets', 'Home', 'Home', 'bedsheet linen blanket'),
      item('Towels', 'Home', 'Home', 'towel'),
      item('Curtains', 'Home', 'Home', 'curtain kurtina'),
      item('Kitchenware', 'Home', 'Home', 'plates cups pots pans'),
      item('Electronics', 'Electronics', 'Other', 'gadgets', true),
      item('Phone cases', 'Electronics', 'Other', 'cellphone case cover'),
      item('Earphones', 'Electronics', 'Other', 'headphones earbuds'),
      item('Chargers', 'Electronics', 'Other', 'charger cable'),
      item('Power banks', 'Electronics', 'Other', 'powerbank')
    ]
  };

  let activeItemCategory = 'All';
  let itemSuggestionsDismissed = false;
  let itemMatches = [];
  let activeItemIndex = -1;
  let sellTriggerToRestoreFocus = null;

  const formatDeliveryDuration = (seconds) => {
    const minutes = Math.max(1, Math.round(seconds / 60));
    const hours = Math.floor(minutes / 60);
    const remainingMinutes = minutes % 60;
    if (!hours) return `${minutes} min`;
    return remainingMinutes ? `${hours} hr ${remainingMinutes} min` : `${hours} hr`;
  };

  const drawDeliveryMap = (destination, routeGeometry = null) => {
    const mapElement = document.getElementById('delivery-map');
    if (!mapElement || !window.L) {
      return false;
    }

    if (deliveryMap) deliveryMap.remove();
    deliveryMap = window.L.map(mapElement).setView([destination.lat, destination.lon], 14);
    window.L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors',
      maxZoom: 19
    }).addTo(deliveryMap);

    const start = [deliveryStart.lat, deliveryStart.lon];
    const end = [destination.lat, destination.lon];
    window.L.marker(start).addTo(deliveryMap).bindPopup('Approximate start: Cainta Municipal Hall');
    window.L.marker(end).addTo(deliveryMap).bindPopup('Delivery destination (approximate)');

    if (routeGeometry) {
      const routePoints = routeGeometry.coordinates.map(([lon, lat]) => [lat, lon]);
      window.L.polyline(routePoints, { color: '#1f72d8', weight: 5, opacity: 0.8 }).addTo(deliveryMap);
      deliveryMap.fitBounds(window.L.latLngBounds([start, ...routePoints, end]), { padding: [24, 24] });
    } else {
      deliveryMap.fitBounds(window.L.latLngBounds([start, end]), { padding: [24, 24] });
    }
    window.setTimeout(() => deliveryMap?.invalidateSize(), 0);
    return true;
  };

  const estimateDeliveryRoute = async () => {
    if (!deliveryAddress || !deliveryEstimate || !deliveryEstimateStatus || !deliveryEstimateSummary) return;
    deliveryEstimate.hidden = false;
    deliveryEstimateSummary.textContent = '';
    deliveryEstimateStatus.textContent = 'Finding the delivery address...';
    if (deliveryMapLink) deliveryMapLink.hidden = true;

    try {
      const addressQuery = `${deliveryAddress.value.trim()}, Cainta, Rizal, Philippines`;
      const geocodeUrl = new URL('https://nominatim.openstreetmap.org/search');
      geocodeUrl.search = new URLSearchParams({
        format: 'jsonv2',
        limit: '1',
        countrycodes: 'ph',
        q: addressQuery
      }).toString();
      const geocodeResponse = await fetch(geocodeUrl);
      if (!geocodeResponse.ok) throw new Error('Address lookup is temporarily unavailable.');
      const places = await geocodeResponse.json();
      if (!Array.isArray(places) || places.length === 0) {
        throw new Error('Address not found. Please include the street, barangay, and city.');
      }

      const destination = { lat: Number(places[0].lat), lon: Number(places[0].lon) };
      if (!Number.isFinite(destination.lat) || !Number.isFinite(destination.lon)) {
        throw new Error('The address lookup returned an invalid location.');
      }

      const osmRoute = `https://www.openstreetmap.org/directions?engine=fossgis_osrm_car&route=${deliveryStart.lat},${deliveryStart.lon};${destination.lat},${destination.lon}`;
      if (deliveryMapLink) {
        deliveryMapLink.href = osmRoute;
        deliveryMapLink.hidden = false;
      }
      const mapAvailable = drawDeliveryMap(destination);
      deliveryEstimateStatus.textContent = 'Calculating the estimated driving route...';

      try {
        const routeUrl = `https://router.project-osrm.org/route/v1/driving/${deliveryStart.lon},${deliveryStart.lat};${destination.lon},${destination.lat}?overview=full&geometries=geojson`;
        const routeResponse = await fetch(routeUrl);
        if (!routeResponse.ok) throw new Error('Routing service is unavailable.');
        const routeResult = await routeResponse.json();
        const route = routeResult.routes?.[0];
        if (
          routeResult.code !== 'Ok' ||
          !route ||
          !Array.isArray(route.geometry?.coordinates) ||
          !Number.isFinite(route.duration) ||
          !Number.isFinite(route.distance)
        ) {
          throw new Error('No driving route was found for this address.');
        }

        deliveryEstimateSummary.textContent =
          `About ${formatDeliveryDuration(route.duration)} by road · ${(route.distance / 1000).toFixed(1)} km`;
        const routeMapAvailable = drawDeliveryMap(destination, route.geometry);
        deliveryEstimateStatus.textContent = routeMapAvailable
          ? 'Route shown from Cainta Municipal Hall to the approximate delivery location.'
          : 'Route estimate ready. The interactive map could not load; use the OpenStreetMap route link.';
      } catch (error) {
        deliveryEstimateStatus.textContent = mapAvailable
          ? `${error.message} The destination is marked on the map.`
          : `${error.message} The interactive map could not load; use the OpenStreetMap route link.`;
      }
    } catch (error) {
      deliveryEstimateStatus.textContent = error.message;
    }
  };

  // Pictures: each item and category has a drawing in the hidden icon sprite inside main.html
  // (symbol ids look like "ic-chicken", "ic-t-shirts"). Anything without a drawing shows a parcel box.
  const categoryIcons = {
    All: 'all',
    Fresh: 'vegetables',
    Pantry: 'cooking-oil',
    Snacks: 'snacks',
    Drinks: 'softdrinks',
    Meals: 'adobo',
    Clothing: 't-shirts',
    Shoes: 'sneakers',
    Bags: 'handbags',
    Accessories: 'watches',
    Home: 'home-decor',
    Electronics: 'electronics'
  };

  const makeIcon = (name) => {
    const svgNS = 'http://www.w3.org/2000/svg';
    const svg = document.createElementNS(svgNS, 'svg');
    svg.setAttribute('viewBox', '0 0 64 64');
    svg.setAttribute('aria-hidden', 'true');
    svg.setAttribute('focusable', 'false');
    const use = document.createElementNS(svgNS, 'use');
    use.setAttribute('href', `#ic-${document.getElementById(`ic-${name}`) ? name : 'default'}`);
    svg.append(use);
    return svg;
  };

  // Edit distance that counts two swapped neighbouring letters as one typo ("shrit" -> "shirt").
  const typoDistance = (a, b) => {
    const rows = Array.from({ length: a.length + 1 }, (_, i) => [i]);
    for (let j = 1; j <= b.length; j += 1) rows[0][j] = j;
    for (let i = 1; i <= a.length; i += 1) {
      for (let j = 1; j <= b.length; j += 1) {
        const cost = a[i - 1] === b[j - 1] ? 0 : 1;
        rows[i][j] = Math.min(rows[i - 1][j] + 1, rows[i][j - 1] + 1, rows[i - 1][j - 1] + cost);
        if (i > 1 && j > 1 && a[i - 1] === b[j - 2] && a[i - 2] === b[j - 1]) {
          rows[i][j] = Math.min(rows[i][j], rows[i - 2][j - 2] + 1);
        }
      }
    }
    return rows[a.length][b.length];
  };

  const isCloseSpelling = (token, words) => {
    const allowed = token.length >= 7 ? 2 : token.length >= 4 ? 1 : 0;
    if (!allowed) return false;
    return words.some((word) => word.length >= 3 && (
      typoDistance(token, word) <= allowed ||
      typoDistance(token, word.slice(0, token.length)) <= allowed
    ));
  };

  // Higher score = better guess. Every word you typed has to match something.
  const scoreItem = (entry, tokens, allowTypos) => {
    let total = 0;
    for (const token of tokens) {
      let best = 0;
      if (entry.nameWords.some((word) => word.startsWith(token))) best = 4;
      else if (entry.nameWords.some((word) => word.includes(token))) best = 2.5;
      else if (entry.alsoWords.some((word) => word.startsWith(token))) best = 2;
      else if (entry.alsoWords.some((word) => word.includes(token))) best = 1.2;
      else if (entry.categoryWords.some((word) => word.startsWith(token))) best = 1;
      else if (allowTypos && (isCloseSpelling(token, entry.nameWords) || isCloseSpelling(token, entry.alsoWords))) best = 0.8;
      if (!best) return 0;
      total += best;
    }
    return total + (entry.key.startsWith(tokens.join(' ')) ? 3 : 0);
  };

  const findItemMatches = (serviceName, query, category) => {
    const pool = (itemCatalog[serviceName] || [])
      .filter((entry) => category === 'All' || entry.category === category);
    const tokens = normalizeItemText(query).split(' ').filter(Boolean);

    if (!tokens.length) {
      const list = category === 'All' ? pool.filter((entry) => entry.popular) : pool;
      return { label: category === 'All' ? 'Popular items' : `${category} items`, entries: list.slice(0, 8), tokens };
    }

    for (const allowTypos of [false, true]) {
      const hits = pool
        .map((entry) => ({ entry, score: scoreItem(entry, tokens, allowTypos) }))
        .filter((hit) => hit.score > 0)
        .sort((a, b) =>
          b.score - a.score ||
          Number(b.entry.popular) - Number(a.entry.popular) ||
          a.entry.name.localeCompare(b.entry.name))
        .slice(0, 6);
      if (hits.length) {
        return {
          label: allowTypos ? 'Did you mean' : 'Suggestions',
          entries: hits.map((hit) => hit.entry),
          tokens: allowTypos ? [] : tokens
        };
      }
    }
    return { label: '', entries: [], tokens };
  };

  const appendHighlighted = (parent, text, tokens) => {
    const parts = [...tokens]
      .sort((a, b) => b.length - a.length)
      .map((token) => token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'));
    if (!parts.length) {
      parent.append(text);
      return;
    }
    text.split(new RegExp(`(${parts.join('|')})`, 'gi')).forEach((piece, index) => {
      if (!piece) return;
      if (index % 2) {
        const mark = document.createElement('mark');
        mark.textContent = piece;
        parent.append(mark);
      } else {
        parent.append(piece);
      }
    });
  };

  const setActiveItem = (index, scroll = true) => {
    const options = itemSuggestionList ? [...itemSuggestionList.querySelectorAll('[role="option"]')] : [];
    activeItemIndex = options.length ? Math.max(-1, Math.min(index, options.length - 1)) : -1;
    options.forEach((option, i) => {
      const on = i === activeItemIndex;
      option.classList.toggle('is-active', on);
      option.setAttribute('aria-selected', String(on));
    });
    if (activeItemIndex >= 0) {
      itemSearch?.setAttribute('aria-activedescendant', options[activeItemIndex].id);
      if (scroll) options[activeItemIndex].scrollIntoView({ block: 'nearest' });
    } else {
      itemSearch?.removeAttribute('aria-activedescendant');
    }
  };

  const pickItem = (entry) => {
    if (!itemSearch || !itemName) return;
    itemSearch.value = entry.name;
    itemName.value = entry.name;
    if (itemCategory) itemCategory.value = entry.group;
    itemSuggestionsDismissed = true;
    renderItemSuggestions(sellServiceField?.value || '', entry.name);
    if (itemSearchStatus) itemSearchStatus.textContent = `${entry.name} selected`;
    itemSearch.focus();
  };

  const renderItemCategories = (serviceName) => {
    if (!itemCategories) return;
    itemCategories.replaceChildren();
    ['All', ...new Set((itemCatalog[serviceName] || []).map((entry) => entry.category))].forEach((category) => {
      const button = document.createElement('button');
      button.className = 'item-category';
      button.type = 'button';
      const image = document.createElement('span');
      image.className = 'item-category-img';
      image.append(makeIcon(categoryIcons[category] || 'default'));
      button.append(image, document.createTextNode(category));
      button.setAttribute('aria-pressed', String(category === activeItemCategory));
      button.addEventListener('click', () => {
        activeItemCategory = category;
        itemSuggestionsDismissed = false;
        itemCategories.querySelectorAll('.item-category').forEach((chip) => {
          chip.setAttribute('aria-pressed', String(chip === button));
        });
        if (category !== 'All' && itemCategory) {
          const sample = (itemCatalog[serviceName] || []).find((entry) => entry.category === category);
          if (sample) itemCategory.value = sample.group;
        }
        renderItemSuggestions(serviceName, itemSearch?.value || '');
      });
      itemCategories.append(button);
    });
  };

  const renderItemSuggestions = (serviceName, query = '') => {
    if (!itemSuggestions || !itemSuggestionList) return;
    itemSuggestionList.replaceChildren();
    activeItemIndex = -1;
    itemSearch?.removeAttribute('aria-activedescendant');

    const result = findItemMatches(serviceName, query, activeItemCategory);
    itemMatches = result.entries;
    const typed = query.trim().length > 0;

    if (itemSuggestionsDismissed || (!result.entries.length && !typed)) {
      itemSuggestions.hidden = true;
      itemSearch?.setAttribute('aria-expanded', 'false');
      if (itemSearchStatus) itemSearchStatus.textContent = '';
      return;
    }

    itemSuggestions.hidden = false;
    itemSearch?.setAttribute('aria-expanded', 'true');

    if (!result.entries.length) {
      itemSuggestionsLabel.textContent = 'No matches';
      const empty = document.createElement('li');
      empty.className = 'item-suggestion-empty';
      empty.setAttribute('role', 'presentation');
      empty.textContent = activeItemCategory === 'All'
        ? 'We could not find that. You can still type your own item and send the request.'
        : `Nothing in ${activeItemCategory} matches. Try All, or type your own item.`;
      itemSuggestionList.append(empty);
      if (itemSearchStatus) itemSearchStatus.textContent = 'No matching items';
      return;
    }

    itemSuggestionsLabel.textContent = result.label;
    result.entries.forEach((entry, index) => {
      const row = document.createElement('li');
      row.className = 'item-suggestion';
      row.id = `item-option-${index}`;
      row.setAttribute('role', 'option');
      row.setAttribute('aria-selected', 'false');

      const image = document.createElement('span');
      image.className = 'item-suggestion-img';
      image.append(makeIcon(entry.icon));

      const text = document.createElement('span');
      text.className = 'item-suggestion-text';
      const name = document.createElement('span');
      name.className = 'item-suggestion-name';
      appendHighlighted(name, entry.name, result.tokens);
      const meta = document.createElement('span');
      meta.className = 'item-suggestion-meta';
      meta.textContent = entry.category;
      text.append(name, meta);
      row.append(image, text);

      row.addEventListener('mousedown', (event) => event.preventDefault());   // keep the cursor in the search box
      row.addEventListener('click', () => pickItem(entry));
      row.addEventListener('mousemove', () => {
        if (activeItemIndex !== index) setActiveItem(index, false);
      });
      itemSuggestionList.append(row);
    });
    if (itemSearchStatus) {
      itemSearchStatus.textContent = `${result.entries.length} suggestion${result.entries.length > 1 ? 's' : ''} available`;
    }
  };

  const openSellModal = (serviceName, trigger) => {
    if (!sellModal || !sellForm || !sellServiceField || !sellTitle || !sellSubtitle) return;
    sellForm.reset();
    sellTitle.textContent = `Buy from ${serviceName}`;
    sellServiceField.value = serviceName;
    sellSubtitle.textContent = serviceName === 'Food Express'
      ? 'Request food items, essentials, and fresh goods for quick local pickup.'
      : 'Request apparel, accessories, and retail items for easy delivery.';
    if (itemCategory) {
      itemCategory.value = serviceName === 'Food Express' ? 'Food' : 'Fashion';
    }
    sellSuccess.hidden = true;
    if (deliveryEstimate) deliveryEstimate.hidden = true;
    deliveryEstimateSummary && (deliveryEstimateSummary.textContent = '');
    deliveryEstimateStatus && (deliveryEstimateStatus.textContent = '');
    deliveryMapLink && (deliveryMapLink.hidden = true);
    if (deliveryMap) {
      deliveryMap.remove();
      deliveryMap = null;
    }
    sellTriggerToRestoreFocus = trigger;
    activeItemCategory = 'All';
    itemSuggestionsDismissed = false;
    renderItemCategories(serviceName);
    renderItemSuggestions(serviceName);
    sellModal.classList.add('open');
    sellModal.setAttribute('aria-hidden', 'false');
    document.body.classList.add('modal-open');
    itemSearch?.focus();
  };

  const closeSellModal = () => {
    if (!sellModal) return;
    sellModal.classList.remove('open');
    sellModal.setAttribute('aria-hidden', 'true');
    document.body.classList.remove('modal-open');
    sellTriggerToRestoreFocus?.focus();
  };

  document.querySelectorAll('.sell-trigger').forEach((button) => {
    button.addEventListener('click', () => {
      const serviceName = button.dataset.service;
      if (serviceName) openSellModal(serviceName, button);
    });
  });

  document.querySelectorAll('[data-close-modal]').forEach((button) => {
    button.addEventListener('click', closeSellModal);
  });

  sellModal?.addEventListener('click', (event) => {
    if (event.target === sellModal) closeSellModal();
  });

  document.addEventListener('keydown', (event) => {
    if (event.key === 'Escape' && sellModal?.classList.contains('open')) {
      closeSellModal();
    }
  });

  itemSearch?.addEventListener('input', (event) => {
    const value = event.target.value.trim();
    if (itemName) {
      itemName.value = value;
    }
    itemSuggestionsDismissed = false;
    renderItemSuggestions(sellServiceField?.value || '', value);
  });

  // Arrow keys move through the suggestions, Enter picks the highlighted one.
  itemSearch?.addEventListener('keydown', (event) => {
    const open = itemSuggestions && !itemSuggestions.hidden && itemMatches.length > 0;
    if (event.key === 'ArrowDown') {
      event.preventDefault();
      if (!open) {
        itemSuggestionsDismissed = false;
        renderItemSuggestions(sellServiceField?.value || '', itemSearch.value);
        setActiveItem(0);
        return;
      }
      setActiveItem(activeItemIndex + 1 >= itemMatches.length ? 0 : activeItemIndex + 1);
    } else if (event.key === 'ArrowUp' && open) {
      event.preventDefault();
      setActiveItem(activeItemIndex <= 0 ? itemMatches.length - 1 : activeItemIndex - 1);
    } else if (event.key === 'Enter' && open && activeItemIndex >= 0) {
      event.preventDefault();
      pickItem(itemMatches[activeItemIndex]);
    }
  });

  sellForm?.addEventListener('submit', async (event) => {
    event.preventDefault();
    sellSuccess.hidden = false;
    if (sellSubmit) {
      sellSubmit.disabled = true;
      sellSubmit.textContent = 'Calculating route...';
    }
    try {
      await estimateDeliveryRoute();
    } finally {
      if (sellSubmit) {
        sellSubmit.disabled = false;
        sellSubmit.textContent = 'Send Order Request';
      }
    }
  });

  /* ============================================================
     LIVE BACKGROUND + SCROLL EFFECTS
     ============================================================ */
  const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  // ---- 1. Mark elements for scroll reveal + parallax -------------------
  const revealTargets = [
    '.hero .eyebrow', '.hero h1', '.hero p', '.hero-actions', '.hero-metrics',
    '.section-head', '.service-card', '.feature-panel', '.stat-card',
    '.process-step', '.cta'
  ];

  revealTargets.forEach((sel) => {
    document.querySelectorAll(sel).forEach((el, i) => {
      el.classList.add('reveal');
      el.style.setProperty('--delay', `${(i % 4) * 0.1}s`);
    });
  });

  // element -> parallax speed (positive = drifts slower than page, negative = faster)
  const parallaxMap = [
    ['.hero-grid > div:first-child', 0.10],
    ['.hero-visual', -0.08],
    ['.section-head', 0.06],
    ['.feature-panel', 0.05],
    ['.stats-box', -0.05],
    ['.service-card:nth-child(2)', 0.05],
    ['.process-step:nth-child(even)', 0.05],
    ['.cta', 0.04]
  ];

  const parallaxEls = [];
  parallaxMap.forEach(([sel, speed]) => {
    document.querySelectorAll(sel).forEach((el) => {
      el.dataset.parallax = speed;
      parallaxEls.push({ el, speed, base: 0 });
    });
  });

  const measure = () => {
    parallaxEls.forEach((p) => {
      p.el.style.translate = 'none';
      const r = p.el.getBoundingClientRect();
      p.base = r.top + window.scrollY + r.height / 2; // page-Y of element centre
    });
  };

  // ---- 2. Reveal on scroll ---------------------------------------------
  if ('IntersectionObserver' in window && !reduceMotion) {
    const io = new IntersectionObserver((entries) => {
      entries.forEach((e) => {
        if (e.isIntersecting) {
          e.target.classList.add('in');
          io.unobserve(e.target);
        }
      });
    }, { threshold: 0.12, rootMargin: '0px 0px -6% 0px' });
    document.querySelectorAll('.reveal').forEach((el) => io.observe(el));
  } else {
    document.querySelectorAll('.reveal').forEach((el) => el.classList.add('in'));
  }

  // ---- 3. Background layers: scroll + mouse parallax -------------------
  const layers = [...document.querySelectorAll('.bg-live .layer')];
  let mouseX = 0, mouseY = 0, smoothMX = 0, smoothMY = 0;

  window.addEventListener('mousemove', (e) => {
    mouseX = (e.clientX / window.innerWidth - 0.5) * 2;
    mouseY = (e.clientY / window.innerHeight - 0.5) * 2;
  }, { passive: true });

  // ---- 4. One animation loop, eased towards the real scroll position ----
  let targetY = window.scrollY;
  let currentY = targetY;

  window.addEventListener('scroll', () => { targetY = window.scrollY; }, { passive: true });
  window.addEventListener('resize', measure);
  window.addEventListener('load', measure);
  measure();

  const frame = () => {
    currentY += (targetY - currentY) * 0.09;   // floaty easing
    smoothMX += (mouseX - smoothMX) * 0.05;
    smoothMY += (mouseY - smoothMY) * 0.05;

    if (!reduceMotion) {
      layers.forEach((layer) => {
        const speed = parseFloat(layer.dataset.speed) || 0.1;
        const mouse = parseFloat(layer.dataset.mouse) || 0;
        layer.style.setProperty('--sy', (currentY * speed).toFixed(2));
        layer.style.setProperty('--mx', (smoothMX * mouse).toFixed(2));
        layer.style.setProperty('--my', (smoothMY * mouse).toFixed(2));
      });

      const viewMid = currentY + window.innerHeight / 2;
      parallaxEls.forEach((p) => {
        const offset = (p.base - viewMid) * p.speed;
        p.el.style.translate = `0 ${offset.toFixed(1)}px`;
      });
    }
    requestAnimationFrame(frame);
  };
  requestAnimationFrame(frame);
});